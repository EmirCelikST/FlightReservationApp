﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightReservationAppEmirCelik
{
    public class Ucak
    {


        public int id { get; set; }
        public string ucakModel { get; set; }
        public string ucakMarkasi { get; set; }
        public string seriNo { get; set; }
        public int koltukKapasitesi { get; set; }




    }
}
