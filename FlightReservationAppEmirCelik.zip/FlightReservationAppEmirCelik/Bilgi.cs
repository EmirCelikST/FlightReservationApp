﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightReservationAppEmirCelik
{
    public class Bilgi
    {
        public int biletFiyatı { get; set; }
        public Rezervasyon Rezervasyon { get; set; }
    }
}
